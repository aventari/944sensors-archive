#include <jni.h>
#include <string>

